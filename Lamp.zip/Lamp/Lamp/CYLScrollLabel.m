//
//  CYLScrollLabel.m
//  Lamp
//
//  Created by caoyinliang on 16/6/13.
//  Copyright © 2016年 51credit. All rights reserved.
//

#import "CYLScrollLabel.h"

@implementation CYLScrollLabel

{
    UILabel         *_lbTitle1;
    UILabel         *_lbTitle2;
    NSInteger       _index;
    NSTimer         *_timer;
    NSMutableArray  *_arrSources;
}

- (instancetype)initWithFrame:(CGRect)frame
{
    if (self == [super initWithFrame:frame])
    {
        [self initSubviews];
    }
    return self;
}
- (void)initSubviews
{
    self.backgroundColor =[UIColor yellowColor];
    self.contentSize = CGSizeMake(self.frame.size.width, self.frame.size.height*2);
    self.pagingEnabled = YES;
    self.showsVerticalScrollIndicator = NO;
    self.scrollEnabled = NO;

    for (int i = 0; i < 2; i++) {
        UILabel *lb=[[UILabel alloc]initWithFrame:CGRectMake(0,self.frame.size.height*i,self.frame.size.width, self.frame.size.height)];
        lb.tag = 2000+i;
        lb.textAlignment =NSTextAlignmentCenter;
        [self addSubview:lb];
    }
    _lbTitle1 =[self viewWithTag:2000];
    _lbTitle2 =[self viewWithTag:2001];
    self.contentOffset = CGPointMake(0, self.frame.size.height);
}
- (void)freshCYLScrollLabel:(NSMutableArray *)arr
{
    _arrSources  = arr;
    if (_arrSources.count>0) {
        _lbTitle2.text =_arrSources[0];
    }
    _timer = [NSTimer scheduledTimerWithTimeInterval:3 target:self selector:@selector(change) userInfo:nil repeats:YES];
}
- (void)change;
{
    _index++;
    _lbTitle1.text = _lbTitle2.text;
    self.contentOffset = CGPointMake(0, 0);
    if (_index<_arrSources.count) {
        _lbTitle2.text = _arrSources[_index];
    } else {
        _index = 0;
        if (_arrSources.count>0) {
            _lbTitle2.text = _arrSources[0];
        }
    }
    [self setContentOffset:CGPointMake(0, self.frame.size.height) animated:YES];
}

@end

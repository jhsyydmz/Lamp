//
//  ViewController.h
//  Lamp
//
//  Created by caoyinliang on 16/6/13.
//  Copyright © 2016年 51credit. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end


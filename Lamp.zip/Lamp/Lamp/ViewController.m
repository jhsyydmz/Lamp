//
//  ViewController.m
//  Lamp
//
//  Created by caoyinliang on 16/6/13.
//  Copyright © 2016年 51credit. All rights reserved.
//

#import "ViewController.h"

#import "CYLScrollLabel.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    NSMutableArray*arr=[@[@"00000000",@"11111111",@"22222222222",@"33333333333",@"444444444444",@"5555555555"] mutableCopy];
    CYLScrollLabel *lb=[[CYLScrollLabel alloc]initWithFrame:CGRectMake(50, 100, self.view.frame.size.width - 100, 50)];
    [self.view addSubview:lb];
    [lb freshCYLScrollLabel:arr];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
